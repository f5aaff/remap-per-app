# Nix installation

run:

```bash
nix profile install .
```

